﻿using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using Game.Models;

namespace Game.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class NewItemPage : ContentPage
    {
        public Item Data { get; set; }

        public NewItemPage()
        {
            InitializeComponent();

            Data = new Item
            {
                Name = "Item name",
                Description = "This is an item description.",
                ModelImage = "ring",
                model = Item.Type.CONSUMABLE,
                Id = Guid.NewGuid().ToString()
            };

            BindingContext = this;
        }

        private async void Save_Clicked(object sender, EventArgs e)
        {
            if((string)modelPicker.SelectedItem == "WEAPON")
            {
                Data.model = Item.Type.WEAPON;
                Data.ModelImage = "sword.png";
            }
            if ((string)modelPicker.SelectedItem == "ARMOR")
            {
                Data.model = Item.Type.ARMOR;
                Data.ModelImage = "armor.png";
            }
            if ((string)modelPicker.SelectedItem == "RING")
            {
                Data.model = Item.Type.RING;
                Data.ModelImage = "ring.png";
            }
            if ((string)modelPicker.SelectedItem == "BOOTS")
            {
                Data.model = Item.Type.BOOTS;
                Data.ModelImage = "shoes.png";
            }
            if ((string)modelPicker.SelectedItem == "CONSUMABLE")
            {
                Data.model = Item.Type.CONSUMABLE;
                Data.ModelImage = "ring.png";
            }

            MessagingCenter.Send(this, "AddData", Data);
            await Navigation.PopAsync();
        }

        private async void Cancel_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}
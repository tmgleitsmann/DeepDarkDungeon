﻿using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using Game.Models;
using Game.ViewModels;

namespace Game.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    // ReSharper disable once RedundantExtendsListEntry
    public partial class MonsterDetailPage : ContentPage
    {
        // ReSharper disable once FieldCanBeMadeReadOnly.Local
        private MonstersDetailViewModel _viewModel;

        public Monster Data { get; set; }
        public string monsterName { get; set; }

        public MonsterDetailPage(MonstersDetailViewModel viewModel)
        {
            // Save off the item
            Data = viewModel.Data;
            monsterName = Data.Name;



            switch (monsterName)
            {
                case "Skeleton":
                    monsterName = "skeleton";
                    break;
                case "Giant Rat":
                    monsterName = "giant_rat";
                    break;
                case "Zombie":
                    monsterName = "zombie";
                    break;
                case "Undead Knight":
                    monsterName = "undead_knight";
                    break;
                case "Rhinosauros":
                    monsterName = "rhino";
                    break;
                case "Boss":
                    monsterName = "boss";
                    break;
                default:
                    monsterName = "newcharacter";
                    break;
            }

            viewModel.Title = "Delete " + viewModel.Title;


            InitializeComponent();


            // Set the data binding for the page
            //BindingContext = _viewModel = viewModel;
            _viewModel = viewModel;
            BindingContext = this;
        }

        public MonsterDetailPage()
        {


            InitializeComponent();

            var data = new Monster
            {
                Name = "Monster",
                Description = "This is an item description.",
                Speed = 1,
                Attack = 1,
                Defense  =1,
                TotalHealth = 10,
                CurrentHealth = 10
            };

            _viewModel = new MonstersDetailViewModel(data);
            BindingContext = _viewModel;
        }

        private async void Edit_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new EditMonsterPage(_viewModel));
        }

        private async void Delete_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new DeleteMonsterPage(_viewModel));
        }

        private async void Cancel_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}
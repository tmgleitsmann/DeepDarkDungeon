﻿using Game.Models;
using Game.ViewModels;
using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Game.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class DeleteMonsterPage : ContentPage
	{
	    // ReSharper disable once NotAccessedField.Local
	    private MonstersDetailViewModel _viewModel;

        public Monster Data { get; set; }

        public string monsterName { get; set; }

        public DeleteMonsterPage(MonstersDetailViewModel viewModel)
        {
            // Save off the item
            Data = viewModel.Data;

            monsterName = Data.Name;

            switch(monsterName)
            {
                case "Skeleton":
                    monsterName = "skeleton";
                    break;
                case "Giant Rat":
                    monsterName = "giant_rat";
                    break;
                case "Zombie":
                    monsterName = "zombie";
                    break;
                case "Undead Knight":
                    monsterName = "undead_knight";
                    break;
                case "Rhinosauros":
                    monsterName = "rhino";
                    break;   
                case "Boss":
                    monsterName = "boss";
                    break;    
                default:
                    monsterName = "newcharacter";
                    break; 
            }

            viewModel.Title = "Delete " + viewModel.Title;


            InitializeComponent();


            // Set the data binding for the page
            //BindingContext = _viewModel = viewModel;
            _viewModel = viewModel;
            BindingContext = this;
        }

	    private async void Delete_Clicked(object sender, EventArgs e)
        {
            MessagingCenter.Send(this, "DeleteData", Data);

            // Remove Item Details Page manualy
            Navigation.RemovePage(Navigation.NavigationStack[Navigation.NavigationStack.Count - 2]);

            await Navigation.PopAsync();
        }

	    private async void Cancel_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}
﻿using System;

using Game.Models;
using Game.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Game.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class EditMonsterPage : ContentPage
	{
	    // ReSharper disable once NotAccessedField.Local
	    private MonstersDetailViewModel _viewModel;

        public Monster Data { get; set; }

        public string monsterName { get; set; }

        public EditMonsterPage(MonstersDetailViewModel viewModel)
        {
            // Save off the item
            Data = viewModel.Data;
            monsterName = Data.Name;
            viewModel.Title = "Edit " + viewModel.Title;

            switch (monsterName)
            {
                case "Skeleton":
                    monsterName = "skeleton";
                    break;
                case "Giant Rat":
                    monsterName = "giant_rat";
                    break;
                case "Zombie":
                    monsterName = "zombie";
                    break;
                case "Undead Knight":
                    monsterName = "undead_knight";
                    break;
                case "Rhinosauros":
                    monsterName = "rhino";
                    break;
                case "Boss":
                    monsterName = "boss";
                    break;
                default:
                    monsterName = "newcharacter";
                    break;
            }

            viewModel.Title = "Delete " + viewModel.Title;


            InitializeComponent();


            // Set the data binding for the page
            //BindingContext = _viewModel = viewModel;
            _viewModel = viewModel;
            BindingContext = this;
        }

	    private async void Save_Clicked(object sender, EventArgs e)
        {
            MessagingCenter.Send(this, "EditData", Data);

            // removing the old ItemDetails page, 2 up counting this page
            Navigation.RemovePage(Navigation.NavigationStack[Navigation.NavigationStack.Count - 2]);

            // Add a new items details page, with the new Item data on it
            await Navigation.PushAsync(new MonsterDetailPage(new MonstersDetailViewModel(Data)));

            // Last, remove this page
            Navigation.RemovePage(this);
        }

	    private async void Cancel_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}
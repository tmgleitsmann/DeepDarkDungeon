﻿using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using Game.Models;

namespace Game.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class NewMonsterPage : ContentPage
    {
        public Monster Data { get; set; }

        public NewMonsterPage()
        {
            InitializeComponent();

            Data = new Monster
            {
                Name = "Monster name",
                Description = "This is a Monster description.",
                Active = true,
                ModelImage = "newcharacter",
                //we need to include level for any monsters added, which means mock and sql dbs will have to have a level attribute stored.
                Id = Guid.NewGuid().ToString()
            };

            BindingContext = this;
        }

        private async void Save_Clicked(object sender, EventArgs e)
        {
            MessagingCenter.Send(this, "AddData", Data);
            await Navigation.PopAsync();
        }

        private async void Cancel_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using Game.Models;
using Game.ViewModels;
using Xamarin.Forms;
using System.Collections.ObjectModel;


namespace Game.Views
{
    public partial class AssignLoot : ContentPage
    {
        ObservableCollection<BaseModel> characterList = new ObservableCollection<BaseModel>();
        ObservableCollection<Item> lootTable = new ObservableCollection<Item>();
        BattleViewModel bvm = new BattleViewModel();
        //Character currentCharacter;
        bool characterSelected;
        const int CONSUMABLES_SIZE = 6;
        const int EQUIPMENT_SIZE = 4;
        int countCharacter;

        public AssignLoot(BattleViewModel _bvm)
        {
            bvm = _bvm;

            InitializeComponent();
            BindingContext = this;
            assignImages();
        }

        void Handle_Tapped(object sender, System.EventArgs e)
        {
            bool item_was_assigned = false;
            if(characterSelected)
            {
                var something = (TappedEventArgs)e;
                int count = Int32.Parse((string)something.Parameter);
                item_was_assigned = bvm.assign_Item(countCharacter, count);
                if(item_was_assigned)
                {
                    if(bvm.updateText != "")
                    {
                        DisplayAlert("Heads Up", bvm.updateText, "OK");
                    }
                    item_was_assigned = false;
                    assignImages();
                }
            }
            characterSelected = false;
        }


        void Handle_Tapped_character(object sender, System.EventArgs e)
        {
            var something = (TappedEventArgs)e;
            countCharacter = Int32.Parse((string)something.Parameter);
            characterSelected = bvm.is_character_active(countCharacter);
        }


        private async void Advance(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new SelectMonsters(bvm.Dataset));
        }

        private void assignImages()
        {
            if (bvm.Dataset[0].Active)
            {
                cImage1.Source = bvm.Dataset[0].ModelImage;
                cName1.Text = bvm.Dataset[0].Name;
            }
            if (bvm.Dataset[1].Active)
            {
                cImage2.Source = bvm.Dataset[1].ModelImage;
                cName2.Text = bvm.Dataset[1].Name;
            }
            if (bvm.Dataset[2].Active)
            {
                cImage3.Source = bvm.Dataset[2].ModelImage;
                cName3.Text = bvm.Dataset[2].Name;
            }
            if (bvm.Dataset[3].Active)
            {
                cImage4.Source = bvm.Dataset[3].ModelImage;
                cName4.Text = bvm.Dataset[3].Name;
            }
            if (bvm.Dataset[4].Active)
            {
                cImage5.Source = bvm.Dataset[4].ModelImage;
                cName5.Text = bvm.Dataset[4].Name;
            }
            if (bvm.Dataset[5].Active)
            {
                cImage6.Source = bvm.Dataset[5].ModelImage;
                cName6.Text = bvm.Dataset[5].Name;
            }

            imageM1.Source = bvm._battleInstance.lootTable[0].ModelImage;
            nameM1.Text = bvm._battleInstance.lootTable[0].Name;
            imageM2.Source = bvm._battleInstance.lootTable[1].ModelImage;
            nameM2.Text = bvm._battleInstance.lootTable[1].Name;
            imageM3.Source = bvm._battleInstance.lootTable[2].ModelImage;
            nameM3.Text = bvm._battleInstance.lootTable[2].Name;
            imageM4.Source = bvm._battleInstance.lootTable[3].ModelImage;
            nameM4.Text = bvm._battleInstance.lootTable[3].Name;
            imageM5.Source = bvm._battleInstance.lootTable[4].ModelImage;
            nameM5.Text = bvm._battleInstance.lootTable[4].Name;
            imageM6.Source = bvm._battleInstance.lootTable[5].ModelImage;
            nameM6.Text = bvm._battleInstance.lootTable[5].Name;
            imageM7.Source = bvm._battleInstance.lootTable[6].ModelImage;
            nameM7.Text = bvm._battleInstance.lootTable[6].Name;
            imageM8.Source = bvm._battleInstance.lootTable[7].ModelImage;
            nameM8.Text = bvm._battleInstance.lootTable[7].Name;
            imageM9.Source = bvm._battleInstance.lootTable[8].ModelImage;
            nameM9.Text = bvm._battleInstance.lootTable[8].Name;

        }
    }
}

﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Game.Views
{
    public partial class SelectTheme : ContentPage
    {
        public SelectTheme()
        {
            InitializeComponent();
        }

        private async void Handle_Clicked(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new SelectCharacters());
        }
    }
}

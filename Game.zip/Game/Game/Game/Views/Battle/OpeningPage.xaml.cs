﻿using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Game.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class OpeningPage : ContentPage
	{
		public OpeningPage ()
		{
			InitializeComponent ();
		}

        private async void UserBattle_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new SelectCharacters());
            //await Navigation.PushAsync(new SelectCharacters());
        }
        private async void AutoBattle_Clicked(object sender, EventArgs e)
        {
            
            await Navigation.PushAsync(new AutoPlay());
        }

        private async void Score_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new ScoresPage());
        }

        private void Button_Clicked(object sender, EventArgs e)
        {

        }

        //void Handle_Clicked(object sender, System.EventArgs e)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
﻿using System;
using System.Collections.Generic;
using Game.Models;
using Game.ViewModels;
using Xamarin.Forms;
using System.Collections.ObjectModel;


namespace Game.Views
{
    public partial class BattleLost : ContentPage
    {
        public Score _scoreInstance;
        //public ScoresViewModel _svm = ScoresViewModel.Instance;

        //ObservableCollection<BaseModel> characterList = new ObservableCollection<BaseModel>();
        //BattleViewModel bvm = new BattleViewModel();
        public BattleLost(BattleViewModel _bvm)
        {
            InitializeComponent();
            exp.Text = "Total Experience Gained: " + _bvm.get_experience_gained().ToString();
            monsters.Text = "Total Monsters Killed: " + _bvm.get_monsters_killed().ToString();
            SetScore(_bvm);
            MessagingCenter.Send(this, "AddData", _scoreInstance);
        }

        private async void Handle_Clicked(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new OpeningPage());
        }

        private void SetScore(BattleViewModel _bvm)
        {

            _scoreInstance = new Score
            {
                ExperienceGainedTotal = _bvm.get_experience_gained(),
                MonstersSlainNumber = _bvm.get_monsters_killed(),
                Id = Guid.NewGuid().ToString(),
                AutoBattle = _bvm._battleInstance.autoPlay,
                GameDate = DateTime.Now,
                TotalRounds = _bvm._battleInstance.rounds,
                CharacterAtDeathList = _bvm.Dataset[0].Name + "\n" + _bvm.Dataset[1].Name + "\n" + _bvm.Dataset[2].Name + "\n" + _bvm.Dataset[3].Name + "\n" +
                                           _bvm.Dataset[5].Name + "\n" + _bvm.Dataset[5].Name
                //MonstersKilledList = ""
            };

            _scoreInstance.ScoreTotal = (_scoreInstance.ExperienceGainedTotal / 50) + (_scoreInstance.MonstersSlainNumber * 100);
            if (_scoreInstance.AutoBattle)
            {
                _scoreInstance.Name = "Auto Battle - " + _scoreInstance.GameDate.ToString("hh:mm:ss tt");
            }
            else
            {
                _scoreInstance.Name = "User Battle - " + _scoreInstance.GameDate.ToString("hh:mm:ss tt");
            }


        }
    }
}

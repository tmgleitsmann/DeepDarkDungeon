﻿using System;

using Game.Models;
using Game.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Collections.ObjectModel;
using System.Collections.Generic;


namespace Game.Views
{
    public partial class SelectMonsters : ContentPage
    {
        const int MAX_CHARACTERS = 5;
        const int EMPTY_SET = 0;
        int i;
        bool modelListCheck;
        ObservableCollection<BaseModel> basemodels;
        ObservableCollection<Monster> monsterList = new ObservableCollection<Monster>();
        MonstersViewModel _viewModel;
        ObservableCollection<Character> _characterList = new ObservableCollection<Character>();

        public SelectMonsters(ObservableCollection<Character> characterList)
        {
            modelListCheck = false;
            InitializeComponent();
            _characterList = characterList;
            BindingContext = _viewModel = MonstersViewModel.Instance;
            i = EMPTY_SET;
        }

        public SelectMonsters(ObservableCollection<BaseModel> modelList)
        {
            modelListCheck = true;
            InitializeComponent();
            basemodels = new ObservableCollection<BaseModel>();
            basemodels = modelList;
            BindingContext = _viewModel = MonstersViewModel.Instance;
            i = EMPTY_SET;

        }


        public async void OnItemSelected(object sender, SelectedItemChangedEventArgs args)
        {

            var data = args.SelectedItem as Monster;
            if (data == null)
            {
                return;
            }

            monsterList.Add(data);

            if(i == MAX_CHARACTERS && !modelListCheck)
            {
                //MonstersViewModel.Instance.Dataset = monsterList;
                await Navigation.PushAsync(new BattleGrid(_characterList, monsterList));
            }
            if(i == MAX_CHARACTERS && modelListCheck)
            {
                await Navigation.PushAsync(new BattleGrid(basemodels, monsterList));
            }
            i++;

            ItemsListView.SelectedItem = null;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            BindingContext = null;

            if (ToolbarItems.Count > 0)
            {
                ToolbarItems.RemoveAt(0);
            }

            InitializeComponent();

            if (_viewModel.Dataset.Count == 0)
            {
                _viewModel.LoadDataCommand.Execute(null);
            }
            else if (_viewModel.NeedsRefresh())
            {
                _viewModel.LoadDataCommand.Execute(null);
            }

            BindingContext = _viewModel;
        }
    }
}

﻿using System;

using Game.Models;
using Game.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Collections.ObjectModel;
using System.Linq;

using System.Collections.Generic;

namespace Game.Views
{
    public partial class BattleGrid : ContentPage
    {
        ObservableCollection<BaseModel> helperType = new ObservableCollection<BaseModel>();
        private int counter;
        private int intent_handler; //0 nothing selected, 1 = attack selected, 2 = defense selected.
        const int HANDLEATTACK = 1;
        const int HANDLEDEFENSE = 2;
        BattleViewModel bvm; //connects view to view model.

        //this constructor will run for the very first battle since characterList hasn't been changed to basemodel version.
        public BattleGrid(ObservableCollection<Character> _characterList, ObservableCollection<Monster> _monsterList)
        {
            bvm = new BattleViewModel(_characterList, _monsterList);
            helperType = bvm.Dataset; //for assigning images only. UI purpose.
            counter = 0; // may not need counter. could be useful in later implementations though.
            InitializeComponent();
            assignImages();
            handle_arrow(bvm.handle_arrow());
        }

        //this constructor will run after the first battle was already fought since characters are basemodels. 
        public BattleGrid(ObservableCollection<BaseModel> modelList, ObservableCollection<Monster> _monsterList)
        {
            bvm = new BattleViewModel(modelList, _monsterList);
            helperType = bvm.Dataset;//for assigning images only. UI purpose.
            counter = 0; // may not need counter. could be useful in later implementations though.
            InitializeComponent();
            assignImages();
            handle_arrow(bvm.handle_arrow());
        }


        void updateTurnDescription()
        {
            if (intent_handler == HANDLEATTACK)
                turnDescription.Text = bvm.updateText + "\n\n" + turnDescription.Text;

            if (intent_handler == HANDLEDEFENSE)
                turnDescription.Text = bvm.updateText + "\n\n" + turnDescription.Text;

            if (intent_handler == 0)
                turnDescription.Text = bvm.Dataset_Speed[counter - 1].Name + "opted to use an item this round\n\n" + turnDescription.Text;
            
            bvm.updateText = "";
            assignImages();
            intent_handler = 0;

        }
        void assignImages()
        {
            double opacity = (double)(helperType[0].CurrentHealth / (double)helperType[0].TotalHealth);
            imageM1.Source = helperType[0].ModelImage;
            barM1.Opacity = opacity;

            opacity = ((double)helperType[1].CurrentHealth / (double)helperType[1].TotalHealth);
            imageM2.Source = helperType[1].ModelImage;
            barM2.Opacity = opacity;

            opacity = ((double)helperType[2].CurrentHealth / (double)helperType[2].TotalHealth);
            imageM3.Source = helperType[2].ModelImage;
            barM3.Opacity = opacity;

            opacity = ((double)helperType[3].CurrentHealth / (double)helperType[3].TotalHealth);
            imageM4.Source = helperType[3].ModelImage;
            barM4.Opacity = opacity;

            opacity = ((double)helperType[4].CurrentHealth / (double)helperType[4].TotalHealth);
            imageM5.Source = helperType[4].ModelImage;
            barM5.Opacity = opacity;

            opacity = ((double)helperType[5].CurrentHealth / (double)helperType[5].TotalHealth);
            imageM6.Source = helperType[5].ModelImage;
            barM6.Opacity = opacity;

            opacity = ((double)helperType[6].CurrentHealth / (double)helperType[6].TotalHealth);
            imageM7.Source = helperType[6].ModelImage;
            nameM7.Text = helperType[6].Name;
            barM7.Opacity = opacity;

            opacity = ((double)helperType[7].CurrentHealth / (double)helperType[7].TotalHealth);
            imageM8.Source = helperType[7].ModelImage;
            nameM8.Text = helperType[7].Name;
            barM8.Opacity = opacity;

            opacity = ((double)helperType[8].CurrentHealth / (double)helperType[8].TotalHealth);
            imageM9.Source = helperType[8].ModelImage;
            nameM9.Text = helperType[8].Name;
            barM9.Opacity = opacity;

            opacity = ((double)helperType[9].CurrentHealth / (double)helperType[9].TotalHealth);
            imageM10.Source = helperType[9].ModelImage;
            nameM10.Text = helperType[9].Name;
            barM10.Opacity = opacity;

            opacity = ((double)helperType[10].CurrentHealth / (double)helperType[10].TotalHealth);
            imageM11.Source = helperType[10].ModelImage;
            nameM11.Text = helperType[10].Name;
            barM11.Opacity = opacity;

            opacity = ((double)helperType[11].CurrentHealth / (double)helperType[11].TotalHealth);
            imageM12.Source = helperType[11].ModelImage;
            nameM12.Text = helperType[11].Name;
            barM12.Opacity = opacity;
        }


        void Handle_Tapped(object sender, System.EventArgs e)
        {
            var something = (TappedEventArgs)e;
            int count = Int32.Parse((string)something.Parameter);

            //count gives us the the target object! 
            int action_value = bvm.handleIntent(intent_handler, count);
            switch(action_value)
            {
                case -2:
                    bvm._battleInstance.generateLoot(); //this will generate loot inside of our battle instance.
                    Navigation.PushAsync(new BattleWon(bvm));
                    break;
                case -1:
                    //This should never run, Battle will never lose after a character hits.
                    //however maybe in future implementations if there is a critical miss that does damage 
                    //to the character then this would be handy.
                    Navigation.PushAsync(new BattleLost(bvm)); 
                    break;
                case 0:
                    //invalid models selected.
                    break;
                case 1:
                    //user chose to defend.
                    invisible_arrows();
                    handle_arrow(bvm.handle_arrow());
                    break;
                case 2:
                    updateTurnDescription();
                    invisible_arrows();
                    handle_arrow(bvm.handle_arrow());
                    break;
                default:
                    break;
            }

        }

        //
        private void invisible_arrows()
        {
            arrow1.IsVisible = false; arrow2.IsVisible = false; arrow3.IsVisible = false;
            arrow4.IsVisible = false; arrow5.IsVisible = false; arrow6.IsVisible = false;
        }

        //
        void handle_arrow(int toggleArrow)
        {
            if(bvm.Dataset.Count == 12)  //if not 12 then we cleared it and battle lost.
             assignImages();
            
            invisible_arrows();
            switch(toggleArrow)
            {
                case -1:
                    //all characters should be eliminated here as result of MonsterAttack
                    Navigation.PushAsync(new BattleLost(bvm));
                    break;
                case 0:
                    //revisit what should happen here...
                    break;
                case 1:
                    arrow1.IsVisible = true; arrow1.Rotation = 180; break;
                case 2:
                    arrow2.IsVisible = true; arrow2.Rotation = 180; break;
                case 3:
                    arrow3.IsVisible = true; arrow3.Rotation = 180; break;
                case 4:
                    arrow4.IsVisible = true; arrow4.Rotation = 180; break;
                case 5:
                    arrow5.IsVisible = true; arrow5.Rotation = 180; break;
                case 6:
                    arrow6.IsVisible = true; arrow6.Rotation = 180; break;
            }
            if(bvm.updateText != "")
            {
                turnDescription.Text = bvm.updateText + "\n\n" + turnDescription.Text;
            }
        }

        void Handle_Clicked(object sender, System.EventArgs e)
        {
            intent_handler = 0; bvm.itemUsed = false;
            Navigation.PushAsync(new UseItem(bvm));

            if(bvm.itemUsed)
            {
                updateTurnDescription();
                bvm.itemUsed = false;
                invisible_arrows();
                handle_arrow(bvm.handle_arrow());
            }

        }

        void Attack_Handler(object sender, System.EventArgs e)
        {
            intent_handler = HANDLEATTACK;
        }

        //currently does not work.
        void Defense_Handler(object sender, System.EventArgs e)
        {
            intent_handler = HANDLEDEFENSE;
            //all we need is the name of the current object for speed.
            //updateTurnDescription(helperSpeed[counter-1].Name, helperSpeed[counter-1].Name, 0);
            //handle_arrow();
        }

    }
}
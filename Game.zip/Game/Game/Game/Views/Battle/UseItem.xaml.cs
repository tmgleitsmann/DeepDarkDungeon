﻿using System;
using System.Collections.Generic;
using Game.Models;
using Xamarin.Forms;
using System.Collections.ObjectModel;
using Game.ViewModels;
using Game.Models;

namespace Game.Views
{
    public partial class UseItem : ContentPage
    {
        BaseModel _modelInstance = new BaseModel();
        ObservableCollection<Item> stuff = new ObservableCollection<Item>();
        BattleViewModel bvm = new BattleViewModel();
        ItemsViewModel ivm = new ItemsViewModel();

        public UseItem(BattleViewModel _bvm)
        {
            bvm = _bvm;
            _modelInstance = bvm.Dataset_Speed[bvm.counter - 1];
            stuff = bvm.populateCollectionItems();
            InitializeComponent();
            BindingContext = stuff;
            _currentHealth.Text = "Current Health Value: " + _modelInstance.CurrentHealth.ToString();
            _totalHealth.Text = "Total Health Value: " + _modelInstance.TotalHealth.ToString();
            int speedVal = _modelInstance.Speed + _modelInstance.equipment[0].SpeedModification + _modelInstance.equipment[1].SpeedModification +
                                             _modelInstance.equipment[2].SpeedModification + _modelInstance.equipment[3].SpeedModification;
            _speed.Text = "Total Speed Value: " +speedVal.ToString();

            int defenseVal = _modelInstance.Defense + _modelInstance.equipment[0].DefenseModification+_modelInstance.equipment[1].DefenseModification + 
                                               _modelInstance.equipment[2].DefenseModification + _modelInstance.equipment[3].DefenseModification;
            _defense.Text = "Defense Value: " + defenseVal.ToString();

            int attackVal = _modelInstance.Attack + _modelInstance.equipment[0].AttackModification + _modelInstance.equipment[1].AttackModification +
                                           _modelInstance.equipment[2].AttackModification + _modelInstance.equipment[3].AttackModification;
            _attack.Text = "Attack Value: " + attackVal.ToString();

            //bvm = _bvm;
            //stuff = new ObservableCollection<Item>();
            //populateStuff(obj.consumables);
            ////_modelInstance = new Character();
            //InitializeComponent();
            //BindingContext = stuff;

        }


        void Handle_ItemSelected(object sender, Xamarin.Forms.SelectedItemChangedEventArgs args)
        {
            var data = args.SelectedItem as Item;
            if (data == null)
            {
                return;
            }
            bvm.itemUsed = true;
            bvm.rid_of_item(data);
            Navigation.PopAsync();
        }
    }

}

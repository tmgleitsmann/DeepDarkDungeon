﻿using System;
using System.Collections.Generic;
using Game.Models;
using Game.ViewModels;
using Xamarin.Forms;

namespace Game.Views
{
    public partial class AutoPlay : ContentPage
    {
        AutoBattleController auto;
        public AutoPlay()
        {
            GameGlobals.autoBattle = true;
            auto = new AutoBattleController();
            InitializeComponent();
        }

        public async void Handle_Clicked(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new BattleLost(auto._bvm));
        }
    }
}

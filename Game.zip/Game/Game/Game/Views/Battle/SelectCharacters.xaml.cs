﻿using System;

using Game.Models;
using Game.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Collections.ObjectModel;
using System.Collections.Generic;


namespace Game.Views
{
    public partial class SelectCharacters : ContentPage
    {
        const int MAX_CHARACTERS = 5;
        const int EMPTY_SET = 0;
        int i;
        ObservableCollection<Character> characterList = new ObservableCollection<Character>();
        CharactersViewModel _viewModel;

        public SelectCharacters()
        {
            InitializeComponent();
            characterList = new ObservableCollection<Character>();
            BindingContext = _viewModel = CharactersViewModel.Instance;
            i = EMPTY_SET;
        }



        public async void OnItemSelected(object sender, SelectedItemChangedEventArgs args)
        {

            var data = args.SelectedItem as Character;
            if (data == null)
            {
                return;
            }
            //for some reason for added characters current health does not get instantiated.
            data.CurrentHealth = data.TotalHealth;
            Character temp = new Character();
            temp = _viewModel.assignCharacter(data);
            characterList.Add(temp);

            if (i == MAX_CHARACTERS)
            {
                //CharactersViewModel.Instance.Dataset = characterList;
                await Navigation.PushAsync(new SelectMonsters(characterList));
            }
            i++;

            ItemsListView.SelectedItem = null;
        }


        protected override void OnAppearing()
        {
            base.OnAppearing();

            BindingContext = null;

            if (ToolbarItems.Count > 0)
            {
                ToolbarItems.RemoveAt(0);
            }

            InitializeComponent();

            if (_viewModel.Dataset.Count == 0)
            {
                _viewModel.LoadDataCommand.Execute(null);
            }
            else if (_viewModel.NeedsRefresh())
            {
                _viewModel.LoadDataCommand.Execute(null);
            }

            BindingContext = _viewModel;
        }

    }
}

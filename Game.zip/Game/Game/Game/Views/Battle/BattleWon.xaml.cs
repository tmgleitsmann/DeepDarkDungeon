﻿using System;
using System.Collections.Generic;
using Game.Models;
using Game.ViewModels;
using Xamarin.Forms;
using System.Collections.ObjectModel;

namespace Game.Views
{
    public partial class BattleWon : ContentPage
    {
        //ObservableCollection<BaseModel> characterList = new ObservableCollection<BaseModel>();
        //ObservableCollection<Item> lootTable = new ObservableCollection<Item>();
        BattleViewModel bvm = new BattleViewModel();
        public BattleWon(BattleViewModel _bvm)
        {
            bvm = _bvm;
            InitializeComponent();

            exp.Text = "Total Experience Gained: "+_bvm.get_experience_gained().ToString();
            monsters.Text = "Total Monsters Killed: "+_bvm.get_monsters_killed().ToString();
            cAlive.Text = "Characters Still Alive: "+_bvm.active_characters().ToString();
            //cDead.Text = "Characters Dead: "+totalCharactersDead.ToString();
        }

        private async void Handle_Clicked(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new AssignLoot(bvm));
        }
    }
}

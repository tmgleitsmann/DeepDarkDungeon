﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Game.Models;
using Character = Game.Models.Character;

namespace Game.Services
{
    public sealed class MockDataStore : IDataStore
    {

        // Make this a singleton so it only exist one time because holds all the data records in memory
        private static MockDataStore _instance;

        public static MockDataStore Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new MockDataStore();
                }
                return _instance;
            }
        }

        private List<Item> _itemDataset = new List<Item>();
        private List<Character> _characterDataset = new List<Character>();
        private List<Monster> _monsterDataset = new List<Monster>();
        private List<Score> _scoreDataset = new List<Score>();

        private MockDataStore()
        {
            var mockItems = new List<Item>
            {
                new Item { Id = Guid.NewGuid().ToString(), ModelImage="club.png", model = Item.Type.WEAPON, Name = "Bloody Club", Description = "Scarier than your average wooden club.", AttackModification = 2, DefenseModification=0, HealthModification=0, SpeedModification=0  },
                new Item { Id = Guid.NewGuid().ToString(), ModelImage="sword.png", model = Item.Type.WEAPON, Name = "Poisoned Dagger", Description = "Small, stealthy, highly lethal.", AttackModification = 4, DefenseModification=0, HealthModification=0, SpeedModification=0  },
                new Item { Id = Guid.NewGuid().ToString(), ModelImage="bow.png", model = Item.Type.WEAPON, Name = "Plastic Bow", Description = "Literally a child's toy.", AttackModification = 1, DefenseModification=0, HealthModification=0, SpeedModification=0  },
                new Item { Id = Guid.NewGuid().ToString(), ModelImage="shoes.png", model = Item.Type.BOOTS, Name = "Runner's Boots", Description = "They even have those little spikes on the bottom.", SpeedModification = 5, DefenseModification=0, HealthModification=0, AttackModification=0  },
                new Item { Id = Guid.NewGuid().ToString(), ModelImage="armor.png", model = Item.Type.ARMOR, Name = "Plate Armor", Description = "Heavy, durable. Can take a beating.", DefenseModification = 3, AttackModification=0, HealthModification=0, SpeedModification=0  },
                new Item { Id = Guid.NewGuid().ToString(), ModelImage="ring.png", model = Item.Type.RING, Name = "Ring of Vitality", Description = "This little ring somehow makes you stronger.", HealthModification = 20, DefenseModification=0, AttackModification=0, SpeedModification=0  },
                new Item { Id = Guid.NewGuid().ToString(), ModelImage="ring.png", model = Item.Type.CONSUMABLE, Name = "Does it all Potion", Description = "Great All Around Potion.", HealthModification = 3, DefenseModification=1, AttackModification=1, SpeedModification=1  },
                new Item { Id = Guid.NewGuid().ToString(), ModelImage="ring.png", model = Item.Type.CONSUMABLE, Name = "Health Potion", Description = "Great for boosting health.", HealthModification = 10, DefenseModification=0, AttackModification=0, SpeedModification=0  },
                new Item { Id = Guid.NewGuid().ToString(), ModelImage="ring.png", model = Item.Type.CONSUMABLE, Name = "Potion of Strength", Description = "Great for boosting strength.", HealthModification = 0, DefenseModification=0, AttackModification=5, SpeedModification=0  }
        };

            foreach (var data in mockItems)
            {
                _itemDataset.Add(data);
            }

            var mockCharacters = new List<Character>
            {
                new Character { Id = Guid.NewGuid().ToString(), equipment = new Item[4], consumables = new Item[6], ModelImage="character.png", Name = "Zaza Pachulia", Description="He'll try to break your legs.", Speed = 3, Attack = 3, Defense = 3, TotalHealth = 15, CurrentHealth = 15, Level = 1 , Active = true, Experience = 0},
                new Character { Id = Guid.NewGuid().ToString(), equipment = new Item[4], consumables = new Item[6], ModelImage="character.png", Name = "Donovan Mitchell", Description="Young and explosive with lots to learn.", Speed = 3, Attack = 3, Defense = 3, TotalHealth = 15, CurrentHealth = 15, Level = 1 , Active = true, Experience = 0},
                new Character { Id = Guid.NewGuid().ToString(), equipment = new Item[4], consumables = new Item[6], ModelImage="character.png", Name = "Draymond Green", Description="He'll kick you." , Speed = 6, Attack = 5, Defense = 5, TotalHealth = 20, CurrentHealth = 20, Level = 2, Active = true, Experience = 300},
                new Character { Id = Guid.NewGuid().ToString(), equipment = new Item[4], consumables = new Item[6], ModelImage="character.png", Name = "Kyrie Irving",  Description="Wants to be the star player." , Speed = 6, Attack = 5, Defense = 5, TotalHealth = 20, CurrentHealth = 20, Level = 2, Active = true, Experience = 300},
                new Character { Id = Guid.NewGuid().ToString(), equipment = new Item[4], consumables = new Item[6], ModelImage="character.png", Name = "Kobe Bryant", Description="Back from retirement to give em the sauce." , Speed = 10, Attack = 8, Defense = 6, TotalHealth = 25, CurrentHealth = 25, Level = 3, Active = true, Experience = 900},
                new Character { Id = Guid.NewGuid().ToString(), equipment = new Item[4], consumables = new Item[6], ModelImage="character.png", Name = "Lebron James", Description="The G.O.A.T." , Speed = 10, Attack = 8, Defense = 6, TotalHealth = 25, CurrentHealth = 25, Level = 3, Active = true, Experience = 900},
                new Character { Id = Guid.NewGuid().ToString(), equipment = new Item[4], consumables = new Item[6], ModelImage="character.png", Name = "Sinatra", Description="Killing the Rap Game" , Speed = 50, Attack = 50, Defense = 50, TotalHealth = 50, CurrentHealth = 50, Level = 10, Active = true, Experience = 64000}
            };

            foreach (var data in mockCharacters)
            {
                _characterDataset.Add(data);
            }

            var mockMonsters = new List<Monster>
            {
                new Monster { Id = Guid.NewGuid().ToString(), ModelImage="skeleton.png", Name = "Skeleton", Description="Skin n bones minus the skin.", Speed = 2, Attack = 2, Defense = 1, TotalHealth = 10, CurrentHealth = 10, Active = true, Level = 1 },
                new Monster { Id = Guid.NewGuid().ToString(), ModelImage="giant_rat.png", Name = "Giant Rat", Description = "Product of a mutant experiment gone horribly wrong.", Speed = 5, Attack = 1, Defense = 1, TotalHealth = 10, CurrentHealth = 10, Active = true, Level = 2 },
                new Monster { Id = Guid.NewGuid().ToString(), ModelImage="zombie.png", Name = "Zombie", Description = "This monster feasts on brains..", Speed = 3, Attack = 4, Defense = 3, TotalHealth = 15, CurrentHealth = 15, Active = true, Level = 2 },
                new Monster { Id = Guid.NewGuid().ToString(), ModelImage="undead_knight.png", Name = "Undead Knight", Description = "Quick and powerful.", Speed = 5, Attack = 7, Defense = 5, TotalHealth = 25, CurrentHealth = 25, Active = true, Level = 3 },
                new Monster { Id = Guid.NewGuid().ToString(), ModelImage="rhino.png", Name = "Rhinoceros", Description = "Savage beasts...", Speed = 10, Attack = 5, Defense = 2, TotalHealth = 25, CurrentHealth = 25, Active = true, Level = 3 },
                new Monster { Id = Guid.NewGuid().ToString(), ModelImage="boss.png", Name = "Boss", Description = "He's the real deal...", Active = true, Speed = 10, Attack = 8, Defense = 7, TotalHealth = 30, CurrentHealth = 30, Level = 5 }
            };

            foreach (var data in mockMonsters)
            {
                _monsterDataset.Add(data);
            }

            var mockScores = new List<Score>
            {
                new Score { Id = Guid.NewGuid().ToString(), Name = "First Score", ScoreTotal = 111},
                new Score { Id = Guid.NewGuid().ToString(), Name = "Second Score", ScoreTotal = 222},
                new Score { Id = Guid.NewGuid().ToString(), Name = "Third Score", ScoreTotal = 333},
            };

            foreach (var data in mockScores)
            {
                _scoreDataset.Add(data);
            }

        }

        // Item
        public async Task<bool> AddAsync_Item(Item data)
        {
            _itemDataset.Add(data);

            return await Task.FromResult(true);
        }

        public async Task<bool> UpdateAsync_Item(Item data)
        {
            var myData = _itemDataset.FirstOrDefault(arg => arg.Id == data.Id);
            if (myData == null)
            {
                return false;
            }

            myData.Update(data);

            return await Task.FromResult(true);
        }

        public async Task<bool> DeleteAsync_Item(Item data)
        {
            var myData = _itemDataset.FirstOrDefault(arg => arg.Id == data.Id);
            _itemDataset.Remove(myData);

            return await Task.FromResult(true);
        }

        public async Task<Item> GetAsync_Item(string id)
        {
            return await Task.FromResult(_itemDataset.FirstOrDefault(s => s.Id == id));
        }

        public async Task<IEnumerable<Item>> GetAllAsync_Item(bool forceRefresh = false)
        {
            return await Task.FromResult(_itemDataset);
        }


        // Character
        public async Task<bool> AddAsync_Character(Character data)
        {
            _characterDataset.Add(data);

            return await Task.FromResult(true);
        }

        public async Task<bool> UpdateAsync_Character(Character data)
        {
            var myData = _characterDataset.FirstOrDefault(arg => arg.Id == data.Id);
            if (myData == null)
            {
                return false;
            }

            myData.Update(data);

            return await Task.FromResult(true);
        }

        public async Task<bool> DeleteAsync_Character(Character data)
        {
            var myData = _characterDataset.FirstOrDefault(arg => arg.Id == data.Id);
            _characterDataset.Remove(myData);

            return await Task.FromResult(true);
        }

        public async Task<Character> GetAsync_Character(string id)
        {
            return await Task.FromResult(_characterDataset.FirstOrDefault(s => s.Id == id));
        }

        public async Task<IEnumerable<Character>> GetAllAsync_Character(bool forceRefresh = false)
        {
            return await Task.FromResult(_characterDataset);
        }


        //Monster
        public async Task<bool> AddAsync_Monster(Monster data)
        {
            _monsterDataset.Add(data);

            return await Task.FromResult(true);
        }

        public async Task<bool> UpdateAsync_Monster(Monster data)
        {
            var myData = _monsterDataset.FirstOrDefault(arg => arg.Id == data.Id);
            if (myData == null)
            {
                return false;
            }

            myData.Update(data);

            return await Task.FromResult(true);
        }

        public async Task<bool> DeleteAsync_Monster(Monster data)
        {
            var myData = _monsterDataset.FirstOrDefault(arg => arg.Id == data.Id);
            _monsterDataset.Remove(myData);

            return await Task.FromResult(true);
        }

        public async Task<Monster> GetAsync_Monster(string id)
        {
            return await Task.FromResult(_monsterDataset.FirstOrDefault(s => s.Id == id));
        }

        public async Task<IEnumerable<Monster>> GetAllAsync_Monster(bool forceRefresh = false)
        {
            return await Task.FromResult(_monsterDataset);
        }

        // Score
        public async Task<bool> AddAsync_Score(Score data)
        {
            _scoreDataset.Add(data);

            return await Task.FromResult(true);
        }

        public async Task<bool> UpdateAsync_Score(Score data)
        {
            var myData = _scoreDataset.FirstOrDefault(arg => arg.Id == data.Id);
            if (myData == null)
            {
                return false;
            }

            myData.Update(data);

            return await Task.FromResult(true);
        }

        public async Task<bool> DeleteAsync_Score(Score data)
        {
            var myData = _scoreDataset.FirstOrDefault(arg => arg.Id == data.Id);
            _scoreDataset.Remove(myData);

            return await Task.FromResult(true);
        }

        public async Task<Score> GetAsync_Score(string id)
        {
            return await Task.FromResult(_scoreDataset.FirstOrDefault(s => s.Id == id));
        }

        public async Task<IEnumerable<Score>> GetAllAsync_Score(bool forceRefresh = false)
        {
            return await Task.FromResult(_scoreDataset);
        }

    }
}
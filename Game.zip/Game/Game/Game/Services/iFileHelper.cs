﻿namespace Game
{
    public interface IFileHelper
    {
        string GetLocalFilePath(string filename);
    }
}


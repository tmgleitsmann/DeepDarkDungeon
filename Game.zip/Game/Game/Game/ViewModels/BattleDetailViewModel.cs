﻿using Game.Models;

namespace Game.ViewModels
{
    public class BattleDetailViewModel : BaseViewModel
    {
        public BaseModel Data { get; set; }
        public BattleDetailViewModel(BaseModel data = null)
        {
            Title = data?.Name;
            Data = data;
        }
    }
}


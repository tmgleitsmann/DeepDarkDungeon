﻿using System;
using Game.Models;
using Game.ViewModels;
using Xamarin.Forms;
using System.Collections.ObjectModel;
using Game.Views;
using System.Linq;

namespace Game.ViewModels
{
    public class AutoBattleController : ContentPage
    {
        ObservableCollection<Character> characterList = new ObservableCollection<Character>();
        ObservableCollection<Monster> monsterList = new ObservableCollection<Monster>();
        CharactersViewModel _cvm = new CharactersViewModel();
        MonstersViewModel _mvm = new MonstersViewModel();
        public BattleViewModel _bvm = new BattleViewModel();
        public ScoresViewModel _svm;
        int totalRounds;

        public AutoBattleController()
        {
            totalRounds = 0;

            //create characters list
            autobattle_characterList();
            //create monsters list
            autobattle_monsterList();
            //battle view model
            _bvm = new BattleViewModel(characterList, monsterList);
            //_bvm.handle_autobattle();
            //have them fight.
            int scenario = 0;
            while(scenario != 1)
            {

                if (scenario == 2)
                {
                    autobattle_monsterList();
                    auto_assign_loot();
                    _bvm = new BattleViewModel(_bvm.Dataset, monsterList);
                    scenario = 0;
                }
                else
                {
                    scenario = _bvm.handle_autobattle();

                    //Used for scores
                    totalRounds++;
                }
            }

            //Used for scores
            _bvm._battleInstance.autoPlay = true;
            _bvm._battleInstance.rounds = totalRounds;
        }

        // I just made auto_assign_loot have each character take 1 Item IF they can.
        public void auto_assign_loot()
        {
            _bvm._battleInstance.generateLoot();
            int j = 0;
            for (int i = 0; i < 6; i++)
            {
                if(_bvm.Dataset[i].Active && j < 9)
                {
                    _bvm.assign_Item(i, j);
                }
                j++;
            }
        }
        public void autobattle_characterList()
        {
            characterList.Clear();
            if (_cvm.Dataset.Count == 0)
            {
                _cvm.LoadDataCommand.Execute(null);
            }
            else if (_cvm.NeedsRefresh())
            {
                _cvm.LoadDataCommand.Execute(null);
            }
            characterList = _cvm.assignCollection();
        }
        public void autobattle_monsterList()
        {
            monsterList.Clear();
            if (_mvm.Dataset.Count == 0)
            {
                _mvm.LoadDataCommand.Execute(null);
            }
            else if (_mvm.NeedsRefresh())
            {
                _mvm.LoadDataCommand.Execute(null);
            }
            monsterList = _mvm.assignCollection();
        }

    }
}


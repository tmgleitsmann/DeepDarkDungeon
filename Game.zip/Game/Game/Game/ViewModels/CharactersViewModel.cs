﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;

using Xamarin.Forms;

using Game.Models;
using Game.Views;
using System.Linq;

namespace Game.ViewModels
{
    public class CharactersViewModel : BaseViewModel
    {
        // Make this a singleton so it only exist one time because holds all the data records in memory
        private static CharactersViewModel _instance;

        public static CharactersViewModel Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new CharactersViewModel();
                }
                return _instance;
            }
        }

        public ObservableCollection<Character> Dataset { get; set; }
        public Command LoadDataCommand { get; set; }

        private bool _needsRefresh;

        public CharactersViewModel()
        {

            Title = "Character List";
            Dataset = new ObservableCollection<Character>();
            LoadDataCommand = new Command(async () => await ExecuteLoadDataCommand());

            MessagingCenter.Subscribe<DeleteCharacterPage, Character>(this, "DeleteData", async (obj, data) =>
            {
                Dataset.Remove(data);
                await DataStore.DeleteAsync_Character(data);
            });

            MessagingCenter.Subscribe<NewCharacterPage, Character>(this, "AddData", async (obj, data) =>
            {
                Dataset.Add(data);
                await DataStore.AddAsync_Character(data);
            });

            MessagingCenter.Subscribe<EditCharacterPage, Character>(this, "EditData", async (obj, data) =>
            {

                // Find the Item, then update it
                var myData = Dataset.FirstOrDefault(arg => arg.Id == data.Id);
                if (myData == null)
                {
                    return;
                }

                myData.Update(data);
                await DataStore.UpdateAsync_Character(data);

                _needsRefresh = true;

            });
        }

        // Return True if a refresh is needed
        // It sets the refresh flag to false
        public bool NeedsRefresh()
        {
            if (_needsRefresh)
            {
                _needsRefresh = false;
                return true;
            }
            return false;
        }

        // Sets the need to refresh
        public void SetNeedsRefresh(bool value)
        {
            _needsRefresh = value;
        }

        private async Task ExecuteLoadDataCommand()
        {
            if (IsBusy)
                return;

            IsBusy = true;

            try
            {
                Dataset.Clear();
                var dataset = await DataStore.GetAllAsync_Character(true);
                foreach (var data in dataset)
                {
                    Dataset.Add(data);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
            finally
            {
                IsBusy = false;
            }
        }

        public Character assignCharacter(Character data)
        {
            Character temp = new Character
            {
                Name = data.Name,
                Attack = data.Attack,
                Defense = data.Defense,
                Speed = data.Speed,
                Id = data.Id,
                ModelImage = data.ModelImage,
                model = data.model,
                MonstersKilled = 0,
                ExperienceGained = 0,
                Active = true,
                CurrentHealth = data.CurrentHealth,
                TotalHealth = data.TotalHealth,
                Experience = data.Experience,
                Level = data.Level,
                Description = data.Description
            };
            for (int j=0; j < 6; j++)
            {
                temp.consumables[j] = new Item
                {
                    Id = "0",
                    AttackModification = 0,
                    DefenseModification = 0,
                    SpeedModification = 0,
                    HealthModification = 0,
                    Name = "",
                    Description = "",
                    model = Item.Type.CONSUMABLE,
                    ModelImage = ""

                };
            }

            for (int b=0; b < 4; b++)
            {
                temp.equipment[b] = new Item
                {
                    Id = "0",
                    AttackModification = 0,
                    DefenseModification = 0,
                    SpeedModification = 0,
                    HealthModification = 0,
                    Name = "",
                    Description = "",
                    ModelImage = ""
                };
                if (b == 0)
                    temp.equipment[0].model = Item.Type.WEAPON;
                else if (b == 1)
                    temp.equipment[1].model = Item.Type.ARMOR;
                else if (b == 2)
                    temp.equipment[2].model = Item.Type.RING;
                else if (b == 3)
                    temp.equipment[3].model = Item.Type.BOOTS;
            }

            return temp;
        }

        public ObservableCollection<Character> assignCollection()
        {
            ObservableCollection<Character> characterList = new ObservableCollection<Character>();
            Random rng = new Random();
            int num_of_elements = Dataset.Count;
            for (int i = 0; i < 6; i++)
            {
                int generate = rng.Next(0, num_of_elements - 1);
                Character temp = new Character
                {
                    Name = Dataset[generate].Name,
                    Attack = Dataset[generate].Attack,
                    Defense = Dataset[generate].Defense,
                    Speed = Dataset[generate].Speed,
                    Level = Dataset[generate].Level,
                    Description = Dataset[generate].Description,
                    Id = Dataset[generate].Id,
                    ModelImage = Dataset[generate].ModelImage,
                    model = Dataset[generate].model,
                    MonstersKilled = 0,
                    ExperienceGained = 0,
                    Active = true,
                    CurrentHealth = Dataset[generate].CurrentHealth,
                    TotalHealth = Dataset[generate].TotalHealth,
                    Experience = Dataset[generate].Experience
                };
                for (int j = 0; j < 6; j++)
                {
                    temp.consumables[j] = new Item
                    {
                        Id = "0",
                        AttackModification = 0,
                        DefenseModification = 0,
                        SpeedModification = 0,
                        HealthModification = 0,
                        Name = "",
                        Description = "",
                        model = Item.Type.CONSUMABLE,
                        ModelImage = ""
                    };
                }
                for (int b = 0; b < 4; b++)
                {
                    temp.equipment[b] = new Item
                    {
                        Id = "0",
                        AttackModification = 0,
                        DefenseModification = 0,
                        SpeedModification = 0,
                        HealthModification = 0,
                        Name = "",
                        Description = "",
                        ModelImage = ""
                    };
                    if (b == 0)
                        temp.equipment[0].model = Item.Type.WEAPON;
                    else if (b == 1)
                        temp.equipment[1].model = Item.Type.ARMOR;
                    else if (b == 2)
                        temp.equipment[2].model = Item.Type.RING;
                    else if (b == 3)
                        temp.equipment[3].model = Item.Type.BOOTS;
                }
                characterList.Add(temp);
            }
            return characterList;
        }

    }
}
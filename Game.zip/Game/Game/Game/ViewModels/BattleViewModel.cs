﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;

using Xamarin.Forms;

using Game.Models;
using Game.Views;
using System.Linq;

namespace Game.ViewModels
{
    public class BattleViewModel : BaseViewModel
    {
        // Make this a singleton so it only exist one time because holds all the data records in memory
        private static BattleViewModel _instance;
        public Battle _battleInstance;
        public int counter;
        public ObservableCollection<BaseModel> Dataset { get; set; }
        public ObservableCollection<BaseModel> Dataset_Speed { get; set; }
        public Command LoadDataCommand { get; set; }
        private bool _needsRefresh;
        public string updateText;

        int damageInflicted;
        public bool itemUsed;

        public static BattleViewModel Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new BattleViewModel();
                }
                return _instance;
            }
        }

        public BattleViewModel(){} //default

        public BattleViewModel(ObservableCollection<Character> characterList, ObservableCollection<Monster> monsterList)
        {
            itemUsed = false;
            damageInflicted = 0;
            updateText = "";
            _battleInstance = new Battle();
            counter = 0;
            Dataset = new ObservableCollection<BaseModel>
            {
                new Monster{ModelImage = monsterList[0].ModelImage, model = monsterList[0].model, Active =monsterList[0].Active, CurrentHealth=monsterList[0].CurrentHealth, TotalHealth=monsterList[0].TotalHealth, Attack = monsterList[0].Attack, 
                    Defense = monsterList[0].Defense, Description=monsterList[0].Description, Id=monsterList[0].Id, Level=monsterList[0].Level, Speed=monsterList[0].Speed, Name=monsterList[0].Name, Visited=false},
                new Monster{ModelImage = monsterList[1].ModelImage, model = monsterList[1].model, Active =monsterList[1].Active, CurrentHealth=monsterList[1].CurrentHealth, TotalHealth=monsterList[1].TotalHealth, Attack = monsterList[1].Attack,
                    Defense = monsterList[1].Defense, Description=monsterList[1].Description, Id=monsterList[1].Id, Level=monsterList[1].Level, Speed=monsterList[1].Speed, Name=monsterList[1].Name, Visited=false},
                new Monster{ModelImage = monsterList[2].ModelImage, model = monsterList[2].model, Active =monsterList[2].Active, CurrentHealth=monsterList[2].CurrentHealth, TotalHealth=monsterList[2].TotalHealth, Attack = monsterList[2].Attack,
                    Defense = monsterList[2].Defense, Description=monsterList[2].Description, Id=monsterList[2].Id, Level=monsterList[2].Level, Speed=monsterList[2].Speed, Name=monsterList[2].Name, Visited=false},
                new Monster{ModelImage = monsterList[3].ModelImage, model = monsterList[3].model, Active =monsterList[3].Active, CurrentHealth=monsterList[3].CurrentHealth, TotalHealth=monsterList[3].TotalHealth, Attack = monsterList[3].Attack,
                    Defense = monsterList[3].Defense, Description=monsterList[3].Description, Id=monsterList[3].Id, Level=monsterList[3].Level, Speed=monsterList[3].Speed, Name=monsterList[3].Name, Visited=false},
                new Monster{ModelImage = monsterList[4].ModelImage, model = monsterList[4].model, Active =monsterList[4].Active, CurrentHealth=monsterList[4].CurrentHealth, TotalHealth=monsterList[4].TotalHealth, Attack = monsterList[4].Attack,
                    Defense = monsterList[4].Defense, Description=monsterList[4].Description, Id=monsterList[4].Id, Level=monsterList[4].Level, Speed=monsterList[4].Speed, Name=monsterList[4].Name, Visited=false},
                new Monster{ModelImage = monsterList[5].ModelImage, model = monsterList[5].model, Active =monsterList[5].Active, CurrentHealth=monsterList[5].CurrentHealth, TotalHealth=monsterList[5].TotalHealth, Attack = monsterList[5].Attack,
                    Defense = monsterList[5].Defense, Description=monsterList[5].Description, Id=monsterList[5].Id, Level=monsterList[5].Level, Speed=monsterList[5].Speed, Name=monsterList[5].Name, Visited=false},

                new Character{MonstersKilled = characterList[0].MonstersKilled, Id = characterList[0].Id, Description = characterList[0].Description, Name = characterList[0].Name, Level = characterList[0].Level, model = characterList[0].model,
                    ModelImage = characterList[0].ModelImage, Active = characterList[0].Active, Attack = characterList[0].Attack, Defense = characterList[0].Defense, Speed = characterList[0].Speed, Experience = characterList[0].Experience,
                    ExperienceGained = characterList[0].ExperienceGained, CurrentHealth=characterList[0].CurrentHealth, TotalHealth = characterList[0].TotalHealth, consumables = characterList[0].consumables, equipment=characterList[0].equipment, Visited=false},
                new Character{MonstersKilled = characterList[1].MonstersKilled, Id = characterList[1].Id, Description = characterList[1].Description, Name = characterList[1].Name, Level = characterList[1].Level, model = characterList[1].model,
                    ModelImage = characterList[1].ModelImage, Active = characterList[1].Active, Attack = characterList[1].Attack, Defense = characterList[1].Defense, Speed = characterList[1].Speed, Experience = characterList[1].Experience,
                    ExperienceGained = characterList[1].ExperienceGained, CurrentHealth=characterList[1].CurrentHealth, TotalHealth = characterList[1].TotalHealth, consumables = characterList[1].consumables, equipment=characterList[1].equipment, Visited=false},
                new Character{MonstersKilled = characterList[2].MonstersKilled, Id = characterList[2].Id, Description = characterList[2].Description, Name = characterList[2].Name, Level = characterList[2].Level, model = characterList[2].model,
                    ModelImage = characterList[2].ModelImage, Active = characterList[2].Active, Attack = characterList[2].Attack, Defense = characterList[2].Defense, Speed = characterList[2].Speed, Experience = characterList[2].Experience,
                    ExperienceGained = characterList[2].ExperienceGained, CurrentHealth=characterList[2].CurrentHealth, TotalHealth = characterList[2].TotalHealth, consumables = characterList[2].consumables, equipment=characterList[2].equipment, Visited=false},
                new Character{MonstersKilled = characterList[3].MonstersKilled, Id = characterList[3].Id, Description = characterList[3].Description, Name = characterList[3].Name, Level = characterList[3].Level, model = characterList[3].model,
                    ModelImage = characterList[3].ModelImage, Active = characterList[3].Active, Attack = characterList[3].Attack, Defense = characterList[3].Defense, Speed = characterList[3].Speed, Experience = characterList[3].Experience,
                    ExperienceGained = characterList[3].ExperienceGained, CurrentHealth=characterList[3].CurrentHealth, TotalHealth = characterList[3].TotalHealth, consumables = characterList[3].consumables, equipment=characterList[3].equipment, Visited=false},
                new Character{MonstersKilled = characterList[4].MonstersKilled, Id = characterList[4].Id, Description = characterList[4].Description, Name = characterList[4].Name, Level = characterList[4].Level, model = characterList[4].model,
                    ModelImage = characterList[4].ModelImage, Active = characterList[4].Active, Attack = characterList[4].Attack, Defense = characterList[4].Defense, Speed = characterList[4].Speed, Experience = characterList[4].Experience,
                    ExperienceGained = characterList[4].ExperienceGained, CurrentHealth=characterList[4].CurrentHealth, TotalHealth = characterList[4].TotalHealth, consumables = characterList[4].consumables, equipment=characterList[4].equipment, Visited=false},
                new Character{MonstersKilled = characterList[5].MonstersKilled, Id = characterList[5].Id, Description = characterList[5].Description, Name = characterList[5].Name, Level = characterList[5].Level, model = characterList[5].model,
                    ModelImage = characterList[5].ModelImage, Active = characterList[5].Active, Attack = characterList[5].Attack, Defense = characterList[5].Defense, Speed = characterList[5].Speed, Experience = characterList[5].Experience,
                    ExperienceGained = characterList[5].ExperienceGained, CurrentHealth=characterList[5].CurrentHealth, TotalHealth = characterList[5].TotalHealth, consumables = characterList[5].consumables, equipment=characterList[5].equipment, Visited=false}
            };

            Dataset_Speed = Dataset;
            Dataset_Speed = new ObservableCollection<BaseModel>(Dataset_Speed.OrderByDescending(x => x.Speed).ThenByDescending(x => x.Level).ThenByDescending(x => x.Name).
                                                                ThenByDescending(x=>x.Experience).ThenBy(x => x.ToString()).ThenBy(x=>x.Name));
        }

        public BattleViewModel(ObservableCollection<BaseModel> characterList, ObservableCollection<Monster> monsterList)
        {
            itemUsed = false;
            damageInflicted = 0;
            updateText = "";
            _battleInstance = new Battle();
            counter = 0;
            Dataset = new ObservableCollection<BaseModel>
            {
                new Monster{ModelImage = monsterList[0].ModelImage, model = monsterList[0].model, Active =monsterList[0].Active, CurrentHealth=monsterList[0].CurrentHealth, TotalHealth=monsterList[0].TotalHealth, Attack = monsterList[0].Attack,
                    Defense = monsterList[0].Defense, Description=monsterList[0].Description, Id=monsterList[0].Id, Level=monsterList[0].Level, Speed=monsterList[0].Speed, Name=monsterList[0].Name, Visited=false},
                new Monster{ModelImage = monsterList[1].ModelImage, model = monsterList[1].model, Active =monsterList[1].Active, CurrentHealth=monsterList[1].CurrentHealth, TotalHealth=monsterList[1].TotalHealth, Attack = monsterList[1].Attack,
                    Defense = monsterList[1].Defense, Description=monsterList[1].Description, Id=monsterList[1].Id, Level=monsterList[1].Level, Speed=monsterList[1].Speed, Name=monsterList[1].Name, Visited=false},
                new Monster{ModelImage = monsterList[2].ModelImage, model = monsterList[2].model, Active =monsterList[2].Active, CurrentHealth=monsterList[2].CurrentHealth, TotalHealth=monsterList[2].TotalHealth, Attack = monsterList[2].Attack,
                    Defense = monsterList[2].Defense, Description=monsterList[2].Description, Id=monsterList[2].Id, Level=monsterList[2].Level, Speed=monsterList[2].Speed, Name=monsterList[2].Name, Visited=false},
                new Monster{ModelImage = monsterList[3].ModelImage, model = monsterList[3].model, Active =monsterList[3].Active, CurrentHealth=monsterList[3].CurrentHealth, TotalHealth=monsterList[3].TotalHealth, Attack = monsterList[3].Attack,
                    Defense = monsterList[3].Defense, Description=monsterList[3].Description, Id=monsterList[3].Id, Level=monsterList[3].Level, Speed=monsterList[3].Speed, Name=monsterList[3].Name, Visited=false},
                new Monster{ModelImage = monsterList[4].ModelImage, model = monsterList[4].model, Active =monsterList[4].Active, CurrentHealth=monsterList[4].CurrentHealth, TotalHealth=monsterList[4].TotalHealth, Attack = monsterList[4].Attack,
                    Defense = monsterList[4].Defense, Description=monsterList[4].Description, Id=monsterList[4].Id, Level=monsterList[4].Level, Speed=monsterList[4].Speed, Name=monsterList[4].Name, Visited=false},
                new Monster{ModelImage = monsterList[5].ModelImage, model = monsterList[5].model, Active =monsterList[5].Active, CurrentHealth=monsterList[5].CurrentHealth, TotalHealth=monsterList[5].TotalHealth, Attack = monsterList[5].Attack,
                    Defense = monsterList[5].Defense, Description=monsterList[5].Description, Id=monsterList[5].Id, Level=monsterList[5].Level, Speed=monsterList[5].Speed, Name=monsterList[5].Name, Visited=false}
            };
            foreach(BaseModel characterObj in characterList)
            {
                characterObj.Visited = false;
                Dataset.Add(characterObj);
            }
            Dataset_Speed = Dataset;
            Dataset_Speed = new ObservableCollection<BaseModel>(Dataset_Speed.OrderByDescending(x => x.Speed).ThenByDescending(x => x.Level).ThenByDescending(x => x.Name).
                                                                ThenByDescending(x => x.Experience).ThenBy(x => x.ToString()).ThenBy(x => x.Name));

        }


        public bool NeedsRefresh()
        {
            if (_needsRefresh)
            {
                _needsRefresh = false;
                return true;
            }
            return false;
        }

        // Sets the need to refresh
        public void SetNeedsRefresh(bool value)
        {
            _needsRefresh = value;
        }

        private async Task ExecuteLoadDataCommand()
        {
            if (IsBusy)
                return;

            IsBusy = true;

            try
            {
                Dataset.Clear();
                var dataset = await DataStore.GetAllAsync_Character(true);
                foreach (var data in dataset)
                {
                    Dataset.Add(data);
                }
                var monsterDataset = await DataStore.GetAllAsync_Monster(true);
                foreach (var data in monsterDataset)
                {
                    Dataset.Add(data);
                }
            }

            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }

            finally
            {
                IsBusy = false;
            }
        }

        public int handleIntent(int userIntent, int count)
        {
            //both character and objects need to be
            if(Dataset_Speed[counter-1].Active && Dataset[count].Active && Dataset_Speed[counter-1].model != Dataset[count].model)
            {
                if (userIntent == 1)
                {
                    //Attack with counter-1
                    int rollValue = _battleInstance.toHitRoll();

                    if(rollValue != 1)
                    {
                        damageInflicted = _battleInstance.Attack(Dataset_Speed[counter - 1], Dataset[count], rollValue);
                        if (damageInflicted >= 0)
                        {
                            updateText = Dataset_Speed[counter - 1].Name + " inflicted " + damageInflicted + " damage to " + Dataset[count].Name;
                            int check_for_battle = _battleInstance.BattleCheck(Dataset);
                            if (check_for_battle == 0)
                            {
                                return 2; //battle still goes. run handle arrow
                            }
                            else if (check_for_battle == 1)
                            {
                                return -1; // this should never hit since it only runs when a character goes.
                            }
                            else
                            {
                                for (int i = 0, j = 12; i < j; i++)
                                {
                                    //if the basemodel is not active or is of type monster.
                                    if (Dataset[i].model == BaseModel.Type.MONSTER)
                                    {
                                        Dataset.Remove(Dataset[i]);
                                        i--; j--;
                                    }
                                }
                                return -2; // no monsters left, battle won.
                            }
                        }
                        return 2;
                    }
                    else
                    {
                        updateText = Dataset_Speed[counter-1].Name+" Missed!";
                        return 2;   
                    }
                }
                else if (userIntent == 2)
                {
                    //Defend. Right now we may not implement this functionality.
                    return 1;
                }
                else
                {
                    //no intent was selected *0*
                    return 0;
                }
            }
            else
                return 0;
        }



        public void counterCheck()
        {
            if (counter >= 12)
            {
                counter=0;
                _battleInstance.rounds++;
                for (int i = 0; i < 12; i++)
                {
                    Dataset[i].Visited = false;
                }
            }
        }


        public int handle_arrow()
        {
            counterCheck();
            Boolean exitVar = false;
            while(!Dataset_Speed[counter].Active)
            {
                Dataset_Speed[counter].ModelImage = "";
                counter++;
                counterCheck();
            }
            int loopcounter = 0;
            int returnValue = 0;
            for (int i = 0; i < 12; i++)
            {
                //compares every object in dataset to whoevers turn it is as long as they are active and can be visited.
                //if the if statement misses, it means that it the arrow corresponding to the loop counter won't be triggered. Increments.
                if (Dataset[i] == Dataset_Speed[counter] && Dataset[i].Visited == false && Dataset[i].Active)
                {
                    switch (loopcounter)
                    {
                        case 0:
                            returnValue = 1; exitVar = true;
                            break;
                        case 1:
                            returnValue = 2; exitVar = true;
                            break;
                        case 2:
                            returnValue = 3; exitVar = true;
                            break;
                        case 3:
                            returnValue = 4; exitVar = true;
                            break;
                        case 4:
                            returnValue = 5; exitVar = true;
                            break;
                        case 5:
                            returnValue = 6; exitVar = true;
                            break;

                        default:
                            break;
                    }
                }
                loopcounter++; //see if the next arrow should be activated.

                if (loopcounter == 6) //only 6 arrows. 
                    loopcounter = 0;
                
                if (exitVar)
                {
                    Dataset[i].Visited = true;
                    if (Dataset_Speed[counter].model == BaseModel.Type.MONSTER && Dataset_Speed[counter].Active)
                    {
                        MonsterAttack();
                        int check_battle = _battleInstance.BattleCheck(Dataset);
                        if(check_battle == 1) // no characters left
                        {
                            returnValue = -1;
                        }
                        else
                        {
                            counter++;
                            returnValue = handle_arrow(); //re-handle the arrow! This may cause issues with the recursion however...    
                        }
                    }
                    else
                    {
                        counter++;
                    }
                    break;
                }
            }
            return returnValue;
        }


        private void MonsterAttack()
        {
            //at this point Dataset_Speed[counter] is going to be an ACTIVE MONSTER
            //dataset should be ordered by model THEN level, so the first character it hits should be the highest level
            //which is what we're going for here.
            foreach(BaseModel obj in Dataset)
            {
                if(obj.Active && obj.model == BaseModel.Type.CHARACTER)
                {
                    int rollValue = _battleInstance.toHitRoll();
                    if(rollValue != 1)
                    {
                        damageInflicted = _battleInstance.MonsterAttack(Dataset_Speed[counter], obj, rollValue);
                        updateText = Dataset_Speed[counter].Name + " inflicted " + damageInflicted + " damage to " + obj.Name + "\n\n" + updateText;
                        break; // we want to break out of the foreach loop.    
                    }
                    else
                    {
                        updateText = Dataset_Speed[counter].Name+" Missed!";
                        break; //we want to break out of the foreach loop.
                    }
                }
            }
            int check_for_battle = _battleInstance.BattleCheck(Dataset);
            if(check_for_battle == 1)
            {
                for (int i = 0, j = 12; i < j; i++)
                {
                    //if the basemodel is not active or is of type monster.
                    if (Dataset[i].model == BaseModel.Type.MONSTER)
                    {
                        Dataset.Remove(Dataset[i]);
                        i--; j--;
                    }
                }
            }
        }

        public void rid_of_item(Item obj)
        {
            Dataset_Speed[counter - 1].Attack += obj.AttackModification;
            Dataset_Speed[counter - 1].Defense += obj.DefenseModification;
            Dataset_Speed[counter - 1].Speed += obj.SpeedModification;
            Dataset_Speed[counter - 1].CurrentHealth += obj.HealthModification;

            if (Dataset_Speed[counter - 1].CurrentHealth > Dataset_Speed[counter - 1].TotalHealth)
                Dataset_Speed[counter - 1].CurrentHealth = Dataset_Speed[counter - 1].TotalHealth;

            _battleInstance.useItem(Dataset_Speed[counter - 1], obj);
            itemUsed = true;

        }

        public ObservableCollection<Item> populateCollectionItems()
        {
            ObservableCollection<Item> stuff = new ObservableCollection<Item>();
            foreach (Item obj in Dataset_Speed[counter-1].consumables)
            {
                if (obj.Id != "0")
                {
                    stuff.Add(obj);
                }
            }
            return stuff;
        }

        public int get_experience_gained()
        {
            int exp_gained = 0;
            foreach(BaseModel obj in Dataset)
            {
                exp_gained += obj.ExperienceGained;
            }
            return exp_gained;
        }
        public int get_monsters_killed()
        {
            int monsters_killed = 0;
            foreach (BaseModel obj in Dataset)
            {
                monsters_killed += obj.MonstersKilled;
            }
            return monsters_killed;
        }
        public int active_characters()
        {
            int activeCharacters = 0;
            foreach (BaseModel obj in Dataset)
            {
                if (obj.Active)
                    activeCharacters++;
            }
            return activeCharacters;
        }
        public bool is_character_active(int count)
        {
            return Dataset[count].Active;
        }
        public bool assign_Item(int countCharacter, int itemCount)
        {
            updateText = "";
            if(Dataset[countCharacter].Active && _battleInstance.lootTable[itemCount].Id != "0") //character should always be active here anyways.
            {
                if(_battleInstance.lootTable[itemCount].model == Item.Type.CONSUMABLE)
                {
                    int assign = is_consumables_full(Dataset[countCharacter]);
                    if(assign == -1)
                    {
                        //consumables is full.
                        updateText = "Sorry! Consumables pouch is full...";
                        return false;
                    }
                    else
                    {
                        Item item = new Item
                        {
                            Id = _battleInstance.lootTable[itemCount].Id,
                            Name = _battleInstance.lootTable[itemCount].Name,
                            Description = _battleInstance.lootTable[itemCount].Description,
                            AttackModification = _battleInstance.lootTable[itemCount].AttackModification,
                            HealthModification = _battleInstance.lootTable[itemCount].HealthModification,
                            SpeedModification = _battleInstance.lootTable[itemCount].SpeedModification,
                            DefenseModification = _battleInstance.lootTable[itemCount].DefenseModification,
                            model = _battleInstance.lootTable[itemCount].model,
                            ModelImage = _battleInstance.lootTable[itemCount].ModelImage
                        };
                        _battleInstance.lootTable[itemCount] = Dataset[countCharacter].consumables[assign];
                        Dataset[countCharacter].consumables[assign] = item;
                        return true;
                    }
                }
                else
                {
                    //Item temp = new Item(); //used to swap Items. 
                    Item item = new Item    //this is used to create a new instance of an object we will populate in our character.
                    {
                        Id = _battleInstance.lootTable[itemCount].Id,
                        Name = _battleInstance.lootTable[itemCount].Name,
                        Description = _battleInstance.lootTable[itemCount].Description,
                        AttackModification = _battleInstance.lootTable[itemCount].AttackModification,
                        HealthModification = _battleInstance.lootTable[itemCount].HealthModification,
                        SpeedModification = _battleInstance.lootTable[itemCount].SpeedModification,
                        DefenseModification = _battleInstance.lootTable[itemCount].DefenseModification,
                        model = _battleInstance.lootTable[itemCount].model,
                        ModelImage = _battleInstance.lootTable[itemCount].ModelImage
                    };
                    //assign will hold the index of where equipment should be stored.
                    int assign = is_equipment_full(Dataset[countCharacter], _battleInstance.lootTable[itemCount].model);
                    _battleInstance.lootTable[itemCount] = Dataset[countCharacter].equipment[assign];
                    //temp = Dataset[countCharacter].equipment[assign];
                    Dataset[countCharacter].equipment[assign] = item;
                    return true;
                }
            }
            return false;
        }

        public int is_equipment_full(BaseModel modelObj, Item.Type type)
        {
            if(type == Item.Type.WEAPON)
            {
                if (modelObj.equipment[0].Id == "0")
                    return 0; //0 will mean grab weapon
                else
                {
                    updateText = "Current weapon slot occupied. Swapping weapons.";
                    return 0;
                }
            }
            else if(type == Item.Type.ARMOR)
            {
                if(modelObj.equipment[1].Id == "0")
                {
                    return 1;
                }
                else
                {
                    updateText = "Current armor slot is occupied. Swapping armor.";
                    return 1;
                }
            }
            else if(type == Item.Type.RING)
            {
                if (modelObj.equipment[2].Id == "0")
                {
                    return 2;
                }
                else
                {
                    updateText = "Current ring slot is occupied. Swapping ring.";
                    return 2;
                }
            }
            else
            {
                if (modelObj.equipment[3].Id == "0")
                {
                    return 3;
                }
                else
                {
                    updateText = "Current boots slot is occupied. Swapping boots.";
                    return 3;
                } 
            }

            //return -1;
        }

        public int is_consumables_full(BaseModel modelobj)
        {
            for (int i = 0; i < 6; i++)
            {
                if(modelobj.consumables[i].Id == "0")
                {
                    return i;
                }
            }
            return -1;
        }

        public int handle_autobattle()
        {
            int scenario =  _battleInstance.autoAttack(Dataset_Speed, Dataset, 0);

            //will remove all the monsters from our dataset. 
            for (int i = 0, j = 12; i < j; i++)
            {
                //if the basemodel is not active or is of type monster.
                if (Dataset[i].model == BaseModel.Type.MONSTER)
                {
                    Dataset.Remove(Dataset[i]);
                    i--; j--;
                }
            }

            return scenario; //if returns 1, all characters dead, if 2 monsters dead
        }

    }
}


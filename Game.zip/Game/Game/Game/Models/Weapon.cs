﻿using System;

using Xamarin.Forms;

namespace Game.Models
{
    public class Weapon : Item
    {
        public Type type; 

        public Weapon(string id, string desc, string name, int attackValue)
        {
            type = Type.WEAPON;
            Description = desc;
            Name = name;
            Id = id;
            AttackModification = attackValue;
        }
    }
}


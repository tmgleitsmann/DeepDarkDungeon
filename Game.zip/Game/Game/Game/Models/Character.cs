﻿
using SQLite;
//using System.Collections.ObjectModel;

namespace Game.Models
{
    public class Character : BaseModel
    {

        public Character()
        {
            consumables = new Item[NUM_OF_CONSUMABLES];
            equipment = new Item[NUM_OF_EQUIPMENT_TYPE];
            model = Type.CHARACTER;
            MonstersKilled = 0;
            ExperienceGained = 0;
            Active = true;
            CurrentHealth = TotalHealth;
            //makes sure character is not creating with anything equiped.
            for (int i = 0; i < NUM_OF_EQUIPMENT_TYPE; i++)
            {
                equipment[i] = new Item();
            }

            //makes sure character is not creating with anything in consumables inventory.
            for (int i = 0; i < NUM_OF_CONSUMABLES; i++)
            {
                consumables[i] = new Item();
            }
        }


        public int getConsumables()
        {
            int num = 0;
            foreach(Item obj in consumables)
            {
                if(obj.Id != "0")
                {
                    num++;
                }
            }
            return num;
        }


        public void Update(Character newData)
        {
            if (newData == null)
            {
                return;
            }

            // Update all the fields in the Data, except for the Id
            Name = newData.Name;
            Description = newData.Description;
            Level = newData.Level;
        }

    }
}
﻿using System;

using Xamarin.Forms;

namespace Game.Models
{
    public class Ring : Item
    {
        public Type type;

        public Ring(string name, string desc, string id, int attackValue, int defenseValue, int speedValue, int healthValue)
        {
            type = Type.RING;
            Description = desc;
            Name = name;
            Id = id;
            AttackModification = attackValue;
            DefenseModification = defenseValue;
            SpeedModification = speedValue;
            HealthModification = healthValue;

        }
    }
}

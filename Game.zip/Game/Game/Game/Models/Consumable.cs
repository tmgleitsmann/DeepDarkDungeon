﻿using System;

using Xamarin.Forms;

namespace Game.Models
{
    public class Consumable : Item
    {
        public Type type;

        public Consumable(string name, string desc, string id, int attackValue, int defenseValue, int speedValue, int healthValue)
        {
            type = Type.CONSUMABLE;
            Description = desc;
            Name = name;
            Id = id;
            AttackModification = attackValue;
            DefenseModification = defenseValue;
            SpeedModification = speedValue;
            HealthModification = healthValue;

        }
    }
}

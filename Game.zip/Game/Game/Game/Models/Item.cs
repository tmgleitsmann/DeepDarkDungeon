﻿
using SQLite;

namespace Game.Models
{
    public class Item
    {
        [PrimaryKey]
        public string Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        //by having this, items will be easier to assign to characters. 
        //you can only wield one at a time per slot maxiumum.
        public enum Type { WEAPON = 0, ARMOR = 1, RING = 2, BOOTS = 3, CONSUMABLE = 4 };
        public Type model;

        public string ModelImage { get; set; }

        //these are attribute modifiying statistics.
        public int HealthModification { get; set; }
        public int AttackModification { get; set; }
        public int DefenseModification { get; set; }
        public int SpeedModification { get; set; }

        //this will be a number from 0-1 on the possibility of the monster dropping said item.
        public int DropChance { get; set; }


        public Item()
        {
            Id = "0";
            Name = "";
            //Id = "0";
            Description = "";
            HealthModification = 0;
            AttackModification = 0;
            DefenseModification = 0;
            SpeedModification = 0;
        }

        public void Update(Item newData)
        {
            if (newData == null)
            {
                return;
            }

            // Update all the fields in the Data, except for the Id
            Name = newData.Name;
            Description = newData.Description;
        }
    }
}
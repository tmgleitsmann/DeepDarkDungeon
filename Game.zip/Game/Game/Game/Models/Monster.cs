﻿using System;
using SQLite;

namespace Game.Models
{
    public class Monster : BaseModel
    {
        public Monster()
        {
            Active = true;
            CurrentHealth = TotalHealth;
            model = Type.MONSTER;
        }

        public void Update(Monster newData)
        {
            if (newData == null)
            {
                return;
            }

            // Update all the fields in the Data, except for the Id
            Name = newData.Name;
            Description = newData.Description;
        }

        public override bool MonsterCheck()
        {
            return true;
        }
    }
}
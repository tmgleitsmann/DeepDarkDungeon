﻿using System;
using SQLite;
using System.Linq;
using System.Collections.ObjectModel;
using Game.ViewModels;

using Xamarin.Forms;

namespace Game.Models
{
    public class Battle : ContentPage
    {
        const int EXP_MULTIPLIER = 20;
        const int GENERATE_ITEMS = 9;
        public int rounds;
        LevelTable _instanceTable;
        ItemsViewModel ivm_instance;
        public ObservableCollection<Item> lootTable;
        bool critHit;
        bool canHit;
        // counts the amount of turns in battle.
        int turnCounter;


        //we should have a canBattleContinue() method that iterates through our observable collection.
        //if no monsters are found, user wins, if no characters are found, then user loses.
        //See notes below, probably better to have this as canBattleContinue()
        
        public bool autoPlay;

        // we need modifier function to calculate TOTAL damage. (not just attack value)
        // this will be a character method. GetModDamage().


        //ObservableCollection<BaseModel>basemodels = new ObservableCollection<BaseModel>();

        /*Constructor will pull chosen characters from the database and populate them into basemodels. 
         *Constructor will generate chosen monsters from the database and populate them into basemodels. 
         *Lastly, the constructor will order basemodels by speed, so our class can iterate through one-by-one
         *to carry out battle functionality. Then startBattle()*/
        public Battle(ObservableCollection<BaseModel> models)
        {
            
            /*This sets our references of collections from battlegrid to our collection in this class.*/
            //basemodels = new ObservableCollection<BaseModel>();
            //basemodels = models;
            _instanceTable = new LevelTable();
            //This will sort our passed model collection by speed then assign it to our classwide variable basemodels.
            //models = new ObservableCollection<BaseModel>(models.OrderBy(x => x.Speed).ToList());
            //basemodels = models;
        }

        public Battle()
        {
            rounds = 0;
            _instanceTable = new LevelTable(); 
        }

        public int toHitRoll()
        {
            if (!GameGlobals.testMissValue)
            {
                Random rnd = new Random();
                //check to see if CritHit possible 
                int hitRoll = rnd.Next(1, 21);
                //if this goes, it means a natural 20 rolled and damage for attack should be doubled
                //attack goes through
                if (hitRoll == 20)
                {
                    if (GameGlobals.critAllowed)
                    {
                        critHit = true;
                    }

                    canHit = true;
                    return 20;
                }
                //no crit, attack still possible 
                //check to see if attack possible 
                //roll was a 1, can't hit
                if (hitRoll == 1)
                {
                    return 1;
                }
                else
                {
                    return hitRoll;
                }
            }
            else
                return 1;

        }


        public void generateLoot()
        {
            //grab our items from our itemsViewModel so that we can generate a table.
            ivm_instance = ItemsViewModel.Instance;
            if (ivm_instance.Dataset.Count == 0)
            {
                ivm_instance.LoadDataCommand.Execute(null);
            }
            //create a new loot table from nothing. Clean slate.
            lootTable = new ObservableCollection<Item>();
            int numOfItemsTotal = ivm_instance.Dataset.Count();
            Random r = new Random(DateTime.Now.Millisecond);

            for (int i = 0; i < GENERATE_ITEMS; i++)
            {
                //generate a number between 0 and number of items in viewmodel -1.
                //populate a new item with the generated index item's value. 
                int temp = r.Next(numOfItemsTotal);
                Item _itemInstance = new Item
                {
                    Name = ivm_instance.Dataset[temp].Name,
                    Description = ivm_instance.Dataset[temp].Description,
                    Id = ivm_instance.Dataset[temp].Id,
                    ModelImage = ivm_instance.Dataset[temp].ModelImage,
                    model = ivm_instance.Dataset[temp].model, 
                    AttackModification = ivm_instance.Dataset[temp].AttackModification,
                    DefenseModification = ivm_instance.Dataset[temp].DefenseModification,
                    SpeedModification = ivm_instance.Dataset[temp].SpeedModification,
                    HealthModification = ivm_instance.Dataset[temp].HealthModification
                };
                //add the item to our loot table.
                lootTable.Add(_itemInstance);
            }

        }

        //Attack function for characters against monsters. We're passing our roll value in. 
        public int Attack(BaseModel obj1, BaseModel obj2, int roll)
        {
            int returnedHitValue = 0;
            //check to see that both objects are active. 
            if (obj1.Active && obj2.Active)
            {
                Random random = new Random();
                int charMod = obj1.equipment[0].AttackModification + obj1.equipment[1].AttackModification + obj1.equipment[2].AttackModification + obj1.equipment[3].AttackModification + obj1.Level + roll;

                //canHit is a boolean variable that is true for roll 20. Gives automatic hit. 
                if (charMod > obj2.Defense + obj2.Level || canHit)
                {
                    //then it can hit. 
                    int damageToDeal = obj1.equipment[0].AttackModification + obj1.equipment[1].AttackModification +
                                           obj1.equipment[2].AttackModification + obj1.equipment[3].AttackModification;
                    if (damageToDeal > 0)
                    {
                        //when character is weilding modifying attributes damage becomes a little more random. 
                        int generateDamage = random.Next(1, damageToDeal);
                        damageToDeal = generateDamage + obj1.Attack+(obj1.Level)/4;

                    }
                    else
                    {   //Damage isn't too random when the character isn't weilding any modifying items. 
                        damageToDeal = obj1.Attack+(obj1.Level)/4;  
                    }


                    int expereinceToGain = damageToDeal = dealDamage(obj2, damageToDeal, obj1);
                    //our experience modifier grants *20. Ie) deal 5 damage, get 100 exp. 
                    expereinceToGain = expereinceToGain * EXP_MULTIPLIER;
                    obj1.Experience += expereinceToGain;
                    obj1.ExperienceGained += expereinceToGain;
                    returnedHitValue = damageToDeal;

                    //the character COULD level up, will check if expereince is met inside the if.
                    if (_instanceTable.LevelDetailsList.Count() > obj1.Level+1)
                    {
                        //if the character has more expereince than what is required, assign level up.
                        if (obj1.Experience >= _instanceTable.LevelDetailsList[obj1.Level + 1].Experience)
                        {
                            obj1.Level++;
                            int healthChange = 0;
                            obj1.Attack = _instanceTable.LevelDetailsList[obj1.Level].Attack;
                            obj1.Defense = _instanceTable.LevelDetailsList[obj1.Level].Defense;
                            obj1.Speed = _instanceTable.LevelDetailsList[obj1.Level].Speed;
                            healthChange = _instanceTable.LevelDetailsList[obj1.Level].Health - obj1.TotalHealth;
                            obj1.TotalHealth = _instanceTable.LevelDetailsList[obj1.Level].Health;
                            obj1.CurrentHealth += healthChange;
                        }
                    }
                }
            }
            critHit = false;
            canHit = false;
            return returnedHitValue;
        }

        //monster attack on character.
        public int MonsterAttack(BaseModel obj1, BaseModel obj2, int roll)
        {
            int returnedHitValue = 0;

            if (obj1.Active && obj2.Active)
            {
                Random random = new Random();
                int charMod = obj1.Level + roll; //monsters can't weild equipment, so no modifiers. 
                int damageToDeal = 0;
                if (charMod > obj2.Defense + obj2.Level) //obj2 is the character
                {
                    damageToDeal = obj1.Attack + (obj1.Level)/4;
                    returnedHitValue = monsterDealDamage(obj2, damageToDeal, obj1);
                }
            }
            critHit = false;
            return returnedHitValue;
        }


        public void Defend(BaseModel obj1)
        {
            //did not add defense functionality into the game as we planned originally. 
        } 


        //make sure this removes item from the character's consumables.
        public void useItem(BaseModel charObject, Item obj)
        {
            int i = 0;
            foreach(Item searchItem in charObject.consumables)
            {
                if(obj == searchItem)
                {
                    charObject.consumables[i] = new Item();
                    break;
                }
            }
        }


        //helper function for our attack functions.
        public int dealDamage(BaseModel obj1, int damageToDeal, BaseModel characterObj)
        {
            //if 20 was rolled or debug setting testCriticalValue was set from about page damage is doubled. 
            if (critHit || GameGlobals.testCriticalValue)
                damageToDeal = damageToDeal * 2;

            critHit = false; 
            obj1.CurrentHealth = obj1.CurrentHealth - damageToDeal;
            if (obj1.CurrentHealth <= 0)
            {
                characterObj.MonstersKilled++;
                damageToDeal = obj1.CurrentHealth + damageToDeal;
                obj1.Active = false;
                obj1.ModelImage = "";
            }

            return damageToDeal;
        }

        //helper function for our monster attack function. This could have honestly have gone as dealDamage...
        public int monsterDealDamage(BaseModel characterobj, int damageToDeal, BaseModel obj1)
        {
            if(critHit || GameGlobals.testCriticalValue)
                damageToDeal = damageToDeal * 2;

            critHit = false;
            characterobj.CurrentHealth = characterobj.CurrentHealth - damageToDeal;
            if (characterobj.CurrentHealth <= 0)
            {
                damageToDeal = obj1.CurrentHealth + damageToDeal;
                characterobj.Active = false;
                characterobj.ModelImage = "";
            }

            return damageToDeal;
                
        }



        public int BattleCheck(ObservableCollection<BaseModel> basemodels)
        {
            foreach (BaseModel characters in basemodels)
            {
                //if it finds a model type CHARACTER that is active then user hasn't lost. 
                if (characters.model == BaseModel.Type.CHARACTER && characters.Active)
                {
                    //there is a character that is still active.
                    foreach (var monsters in basemodels)
                    {
                        if (monsters.model == BaseModel.Type.MONSTER && monsters.Active)
                            return 0; //monsters left.
                    }
                    //we should populate a loot collection.
                    return 2; //no monsters left.
                }
            }
            return 1; //no character models left, user has lost. 
        }


        public int autoAttack(ObservableCollection<BaseModel> speed, ObservableCollection<BaseModel> type, int count)
        {
            if (count == 12) //reset our index back to 0 to avoid index out of bounds. 
            {
                count = 0;
            }
            if (speed[count].Active && speed[count].model == BaseModel.Type.CHARACTER)
            {
                for (int i = 0; i < 12; i++)
                {
                    if (type[i].Active && type[i].model == BaseModel.Type.MONSTER)
                    {
                        int roll = toHitRoll();
                        if (roll == 1)
                            i = 12;
                        //nothing happens
                        else
                        {
                            Attack(speed[count], type[i], roll);
                            i = 12;
                        }
                    }
                }
            }
            if (speed[count].Active && speed[count].model == BaseModel.Type.MONSTER)
            {
                for (int i = 0; i < 12; i++)
                {
                    if (type[i].Active && type[i].model == BaseModel.Type.CHARACTER)
                    {
                        int roll = toHitRoll();
                        if (roll == 1)
                            i = 12;
                        //nothing happens
                        else
                        {
                            MonsterAttack(speed[count], type[i], roll);
                            i = 12;
                        }
                    }
                }
            }
            count++;
            int determine = BattleCheck(type);
            if (determine == 0)
            {
                determine = autoAttack(speed, type, count);
            }
            return determine;
        }





        //public void assignItems(Item item, BaseModel obj)
        //{
        //    //obj.ItemInventory.Add(item);
        //}

    }
}
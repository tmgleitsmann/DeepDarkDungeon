﻿using System.Collections.Generic;

namespace Game.Models
{
    class LevelTable
    {
        #region Singleton
        // Make this a singleton so it only exist one time because holds all the data records in memory
        private static LevelTable _instance;

        public static LevelTable Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new LevelTable();
                }
                return _instance;
            }
        }

        #endregion Singleton

        // Level Max
        public const int MaxLevel = 20;

        // List of all the levels
        public List<LevelDetails> LevelDetailsList { get; set; }

        // Data for the Levels
        public LevelTable()
        {
            LevelDetailsList = new List<LevelDetails>();
            LoadLevelData();
        }

        // Level data set, 0 - 10
        public void LoadLevelData()
        {
            // Init the level list, going to index into it like an array, so making 0 be a null value.  That way Level can be Array Index.
            LevelDetailsList.Add(new LevelDetails(0, 0, 0, 0, 0, 0));
            LevelDetailsList.Add(new LevelDetails(1, 0, 3, 3, 3, 15));
            LevelDetailsList.Add(new LevelDetails(2, 300, 5, 5, 6, 20));
            LevelDetailsList.Add(new LevelDetails(3, 900, 8, 6, 10, 25));
            LevelDetailsList.Add(new LevelDetails(4, 2700, 10, 8, 12, 30));
            LevelDetailsList.Add(new LevelDetails(5, 6500, 13, 11, 15, 35));
            LevelDetailsList.Add(new LevelDetails(6, 14000, 16, 14, 18, 40));
            LevelDetailsList.Add(new LevelDetails(7, 23000, 18, 16, 20, 45));
            LevelDetailsList.Add(new LevelDetails(8, 34000, 21, 19, 22, 50));
            LevelDetailsList.Add(new LevelDetails(9, 48000, 24, 22, 24, 55));
            LevelDetailsList.Add(new LevelDetails(10, 64000, 26, 25, 27, 60));

            LevelDetailsList.Add(new LevelDetails(11, 82000, 28, 27, 30, 65));
            LevelDetailsList.Add(new LevelDetails(12, 102000, 30, 30, 32, 70));
            LevelDetailsList.Add(new LevelDetails(13, 124000, 32, 31, 35, 75));
            LevelDetailsList.Add(new LevelDetails(14, 146000, 33, 32, 36, 80));
            LevelDetailsList.Add(new LevelDetails(15, 170000, 35, 34, 38, 85));
            LevelDetailsList.Add(new LevelDetails(16, 196000, 38, 34, 40, 90));
            LevelDetailsList.Add(new LevelDetails(17, 224000, 40, 37, 42, 95));
            LevelDetailsList.Add(new LevelDetails(18, 250000, 42, 39, 44, 100));
            LevelDetailsList.Add(new LevelDetails(19, 275000, 45, 41, 45, 105));
            LevelDetailsList.Add(new LevelDetails(20, 300000, 50, 43, 46, 110));
            //LevelDetailsList.Add(new LevelDetails(21, 0, 0, 0, 0, 0));
            //LevelDetailsList.Add(new LevelDetails(10, 64000, 26, 25, 27, 60));
        }
    }

    // Level details for each level
    class LevelDetails
    {
        public int Level;
        public int Experience;
        public int Attack;
        public int Defense;
        public int Speed;
        public int Health;

        // Create a new level based on values passed in
        public LevelDetails(int level, int experience, int attack, int defense, int speed, int health)
        {
            Level = level;
            Experience = experience;
            Attack = attack;
            Defense = defense;
            Speed = speed;
            Health = health;
        }
    }
}

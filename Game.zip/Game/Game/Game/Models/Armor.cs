﻿using System;

using Xamarin.Forms;

namespace Game.Models
{
    public class Armor : Item
    {
        public Type type;

        public Armor(string name, string desc, string id, int defenseValue, int speedValue)
        {
            type = Type.ARMOR;
            Description = desc;
            Name = name;
            Id = id;
            AttackModification = 0;
            DefenseModification = defenseValue;
            SpeedModification = speedValue;
            HealthModification = 0;

        }
    }
}

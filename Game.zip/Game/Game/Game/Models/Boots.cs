﻿using System;

using Xamarin.Forms;

namespace Game.Models
{
    public class Boots : Item
    {
        public Type type;

        public Boots(string name, string desc, string id, int speedValue)
        {
            type = Type.BOOTS;
            Description = desc;
            Name = name;
            Id = id;
            AttackModification = 0;
            DefenseModification = 0;
            SpeedModification = speedValue;
            HealthModification = 0;

        }
    }
}

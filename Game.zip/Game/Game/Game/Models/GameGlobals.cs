﻿
// Global switches for the overall game to use...

namespace Game.Models
{
    public static class GameGlobals
    {
        // Turn on to force Rolls to be non random
        public static bool ForceRollsToNotRandom = false;

        // What number should return for random numbers (1 is good choice...)
        public static int ForcedRandomValue = 1;

        // What number to use for ToHit values (1,2, 19, 20)
        public static int ForceToHitValue = 20;

        // Allow Random Items when monsters die...
        public static bool AllowMonsterDropItems = true;

        public static bool CriticalMiss = false;

        public static bool critAllowed = false;

        public static bool randomBadThings = false;

        public static string hitVal = "-1";

        public static bool useHitVal = true;

        public static bool autoBattle = false;

        public static bool testCriticalValue = false;

        public static bool testMissValue = false;

        // Turn Off Random Number Generation, and use the passed in values.
        public static void SetForcedRandomNumbers(int value, int hit)
        {
            ForceRollsToNotRandom = true;
            ForcedRandomValue = value;
            ForceToHitValue = hit;
        }

        // Flip the Random State (false to true etc...)
        // Call this after setting, to restore...
        public static void ToggleRandomState()
        {
            ForceRollsToNotRandom = !ForceRollsToNotRandom;
        }
    }
}

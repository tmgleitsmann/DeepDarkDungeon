﻿using SQLite;
using System;

using Xamarin.Forms;

namespace Game.Models
{
    public class BaseModel
    {
        [PrimaryKey]
        public string Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public int Defense { get; set; }

        public int Attack { get; set; }

        public int Speed { get; set; }

        public int TotalHealth { get; set; }

        public int CurrentHealth { get; set; }

        public string ModelImage { get; set; }

        public int Level { get; set; }

        public enum Type { MONSTER = 0, CHARACTER = 1 };
        public Type model;

        public bool Visited;
        //this 
        public int tempDefense { get { return Defense * 2; } }

        public bool Active { get; set; }

        public int Experience { get; set; }


        public const int NUM_OF_EQUIPMENT_TYPE = 4;
        public const int NUM_OF_CONSUMABLES = 6;

        //to store item in equipment, Type must be 0-3 (Weapon, Armor, Ring, Boots)
        //public Item[] equipment = new Item[NUM_OF_EQUIPMENT_TYPE];
        public Item[] equipment;
        //to store item in equipment, Type must be 4 (Consumable)
        //public Item[] consumables = new Item[NUM_OF_CONSUMABLES];

        public Item[] consumables;

        //public int Level { get; set; }

        public int MonstersKilled { get; set; }
        public int ExperienceGained { get; set; }
        //this is a boolean value only for monsters. 
        //useful for battle model when checking for if an object is a monster.
        //this should probably be a property rather than a method. 

        public BaseModel()
        {
            Visited = false;
        }
        public virtual bool MonsterCheck()
        {
            return false;
        }

    }
}

